export default function Credit() {
  console.log(
    '%cDeveloped by ― Reksa Andhika // http://reksaandhika.com',
    'background-color: black ; color: white ; font-weight: bold ;'
  );
}
