1. Set meta tag
2. Favicon
3. Font
4. Images
5. Variables scss
6. Google analytics